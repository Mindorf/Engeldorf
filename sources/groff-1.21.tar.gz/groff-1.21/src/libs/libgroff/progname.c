const char *program_name = 0;
